# Відключення реклами у Utorrent

1. Запустіть Utorrent та відкрийте головне вікно програми.
2. Перейдіть у меню Налаштування -> Налаштування програми (Ctrl+P).
3. У вікні, що відкрилося, оберіть пункт "Додатково".
4. Ви повинні побачити список змінних налаштувань Utorrent та їх значень.
5. Переключіть всі зазначені нижче змінні у значення False:
    - offers.left_rail_offer_enabled
    - offers.sponsored_torrent_offer_enabled
    - offers.content_offer_autoexec
    - offers.featured_content_badge_enabled
    - offers.featured_content_notifications_enabled
    - offers.featured_content_rss_enabled
    - bt.enable_pulse
    - distributed_share.enable
    - gui.show_plus_upsell
    - gui.show_notorrents_node
6. Натисніть "Ок", але не поспішайте, щоб повністю видалити всю рекламу потрібно зробити ще один крок.
7. У головному вікні Utorrent утримуйте клавіші Shift+F2 та знову, утримуючи їх, зайдіть у Налаштування програми -> Додатково.
8. Цього разу ви побачите інші налаштування, які за замовчуванням приховано.
9. З цих налаштувань потрібно вимкнути наступні:
    - gui.show_gate_notify
    - gui.show_plus_av_upsell
    - gui.show_plus_conv_upsell
    - gui.show_plus_upsell_nodes
10. Потім натисніть Ок, вийдіть з Utorrent (не просто закрийте вікно, а саме вийдете – меню Файл -> Вихід).
11. Запустіть програму знов, цього разу ви побачите Utorrent без реклами.
