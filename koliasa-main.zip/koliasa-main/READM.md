<h3 align="center">***</h3>
<h2 align="center"></h2>
 
<h3 align="center">A social network for the interaction of people in any field, entertainment, business, science ...</h3>

<p align="center">
    <a href="https://xn--80aja5axd.com/register">Register</a>
    ·
    <a href="https://xn--80aja5axd.com/terms/terms">Terms of use</a>
    ·
    <a href="https://xn--80aja5axd.com/terms/privacy-policy">Privacy policy</a>
    ·
    <a href="https://xn--80aja5axd.com/contact-us">Ask Question</a>
  </p>
  <p align="center">
    <a href="https://xn--80aja5axd.com/?lang=english">English </a>
    ·
    <a href="https://xn--80aja5axd.com/?lang=german">Deutsch</a>
    ·
    <a href="https://xn--80aja5axd.com/?lang=swedish">Svenska</a>
     ·
    <a href="https://xn--80aja5axd.com/?lang=french">Français</a>
    ·
    <a href="https://xn--80aja5axd.com/?lang=italian">Italiano</a>
    .
    <a href="https://xn--80aja5axd.com/?lang=turkish">Türk</a>
    .
    <a href="https://xn--80aja5axd.com/?lang=korean">한국어</a>
    .
    <a href="https://xn--80aja5axd.com/?lang=hindi">हिन्दी</a>
    ·
    <a href="https://xn--80aja5axd.com/?lang=arabic">عربى</a>
    ·
    <a href="https://xn--80aja5axd.com/?lang=japanese">日本</a>
    ·
    <a href="https://xn--80aja5axd.com/?lang=chinese">中國人</a>

  </p>
</p>

<h5 align="right">Languages and Tools:</h5>
<p align="right"> <a href="https://www.w3schools.com/css/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> </a> <a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://www.mysql.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a> <a href="https://www.php.net" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg" alt="php" width="40" height="40"/> </a> </p>
<br>
