import paho.mqtt.client as mqtt
import ssl
import time

# Setting up the connection to the MQTT broker
MQTT_HOST = "server_ip_address"
MQTT_PORT = 8883
MQTT_KEEPALIVE_INTERVAL = 45
MQTT_TLS_ENABLED = True
MQTT_USERNAME = "username"
MQTT_PASSWORD = "password"
MQTT_CA_CERTS = "/path/to/ca/cert.pem"
MQTT_CERTFILE = "/path/to/cert.pem"
MQTT_KEYFILE = "/path/to/key.pem"

# Connection to MQTT broker
def on_connect(client, userdata, flags, rc):
    print("Connected to MQTT broker with result code " + str(rc))
    client.subscribe("drone/telemetry")

# Processing of received messages
def on_message(client, userdata, msg):
    print("Received message on topic " + msg.topic + " with payload " + str(msg.payload))

# Connection to MQTT broker
ground_station_client = mqtt.Client()
ground_station_client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
if MQTT_TLS_ENABLED:
    ground_station_client.tls_set(
        ca_certs=MQTT_CA_CERTS,
        certfile=MQTT_CERTFILE,
        keyfile=MQTT_KEYFILE,
        cert_reqs=ssl.CERT_REQUIRED,
        tls_version=ssl.PROTOCOL_TLSv1_2
    )
ground_station_client.on_connect = on_connect
ground_station_client.on_message = on_message
ground_station_client.connect(MQTT_HOST, MQTT_PORT, MQTT_KEEPALIVE_INTERVAL)

# Sending messages to the drone
while True:
    ground_station_client.publish("drone/commands", "takeoff")
    time.sleep(2)
    ground_station_client.publish("drone/commands", "land")
    time.sleep(2)

#This code sets up an MQTT broker connection on the server and sends commands to the drone via the drone/commands topic.
#When receiving telemetry from a drone via the drone/telemetry topic, it outputs the received data to the console.
