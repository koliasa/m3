## This drone code does the following:
- Establishes a connection to the MQTT broker on the server.
- When receiving a command from a ground station ("drone/command" topic), displays it on the screen.
- Processes drone data (in our case - generates test data) and transmits it to the broker ("drone/telemetry" topic) with an interval of 1 second.
These three modules (server.py, ground_station.py, and drone.py) together create a means of communicating data between the ground station and the drone via an MQTT broker on the server.
